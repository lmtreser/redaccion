# Fullscreen

This plugin puts your presentation into fullscreen by pressing *F5*. You can leave fullscreen again by pressing *Esc*. 

*Note:* impress.js works just fine with the normal fullscreen offered by your browser where you would (usually) press *F11* to enter it. There are certain circumstances where you might want to use this plugin instead, as it should work with the impressConsole plugin as well.
