Navigation UI plugin
====================

This plugin provides UI elements "back", "forward" and a list to select
a specific slide number.

Element attribut title is used for select option content if available, it uses element id if no title is provided.

The navigation controls are visible if the toolbar plugin is enabled. To add the toolbar to your
presentations, [see toolbar plugin README](../toolbar/README.md).

Author
------

Henrik Ingo (@henrikingo), 2016
